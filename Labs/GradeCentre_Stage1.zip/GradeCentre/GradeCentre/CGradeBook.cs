﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeCentre
{
    public class CGradeBook
    {
        // All Student Grades
        private int grade1;
        private int grade2;
        private int grade3;
        private int grade4;
        private int grade5;

        /// <summary>
        /// Auto Implemented Property for returning the module name
        /// </summary>
        public string ModuleName { get; }


        /// <summary>
        /// Constructor with name of module and the marks of each of the 5 students
        /// </summary>
        /// <param name="name">Name of the Module</param>
        /// <param name="grade_1">Student 1 Grade</param>
        /// <param name="grade_2">Student 2 Grade</param>
        /// <param name="grade_3">Student 3 Grade</param>
        /// <param name="grade_4">Student 4 Grade</param>
        /// <param name="grade_5">Student 5 Grade</param>
        public CGradeBook(string name, int grade_1, int grade_2, int grade_3, int grade_4, int grade_5)
        {
            ModuleName = name;
            grade1 = grade_1;
            grade2 = grade_2;
            grade3 = grade_3;
            grade4 = grade_4;
            grade5 = grade_5;
        }

        /// <summary>
        /// Find the minimum mark of all students
        /// </summary>
        /// <returns>The minimum mark found</returns>
        public int GetMinimum()
        {
            int min = grade1;
            min = Math.Min(min, grade2);
            min = Math.Min(min, grade3);
            min = Math.Min(min, grade4);
            min = Math.Min(min, grade5);            
            
            return min;
        }

        /// <summary>
        /// Find the maximum mark of all students
        /// </summary>
        /// <returns>The maximum mark found</returns>
        public int GetMaximum()
        {
            int max = grade1;
            max = Math.Max(max, grade2);
            max = Math.Max(max, grade3);
            max = Math.Max(max, grade4);
            max = Math.Max(max, grade5);

            return max;
        }

        /// <summary>
        /// Calculates the average mark
        /// </summary>
        /// <returns>The average mark</returns>
        public double GetAverage()
        {
            double average = 0;

            average = (grade1 + grade2 + grade3 + grade4 + grade5) / 5;

            return average;
        }

        /// <summary>
        /// Creates a string to shows a list of students with their correspoding mark
        /// </summary>
        /// <returns>A line for each student and their mark for example for a student with mark 23 
        /// it would output:
        /// Student 1: 23
        /// </returns>
        public string GetAllStudentGradesString()
        {
            string allGrades = "";
            allGrades = GradeLine(grade1, 1);
            allGrades += Environment.NewLine;
            allGrades += GradeLine(grade2, 2);
            allGrades += Environment.NewLine;
            allGrades += GradeLine(grade3, 3);
            allGrades += Environment.NewLine;
            allGrades += GradeLine(grade4, 4);
            allGrades += Environment.NewLine;
            allGrades += GradeLine(grade5, 5);
            allGrades += Environment.NewLine;

            return allGrades;
        }

        /// <summary>
        /// Creates a single line for displaying a student mark
        /// </summary>
        /// <param name="grade">the grade associated with the student</param>
        /// <param name="studentid">the id of the student</param>
        /// <returns>Student with a mark for example a student with mark 23 
        /// it would output:
        /// Student 1: 23
        /// </returns>
        private string GradeLine(int grade, int studentid)
        {
            return "Student " + studentid.ToString() + ": " + grade.ToString();
        }

        /// <summary>
        /// Ouptuts a frequency table for each marks between 0-9, 10-19, 20-29,30-39....
        /// </summary>
        /// <returns>The string of the frequency table.</returns>
        public string GetAllStudentGradesDistribution()
        {
            string gradeFrequencyTable = "";

            for (int count = 0; count < 10; count++)
            {
                if (count == 9)
                {
                    gradeFrequencyTable += "90-100: ";
                }
                else
                {
                    gradeFrequencyTable += $"{count * 10:D2} {count * 10 + 9:D2} : ";
                }

                if (((grade1 >= count * 10) && (grade1 <= count * 10 + 9)) || (count == 9 && grade1 == 100))
                {
                    gradeFrequencyTable += "*";
                }

                if (((grade2 >= count * 10) && (grade2 <= count * 10 + 9)) || (count == 9 && grade2 == 100))
                {
                    gradeFrequencyTable += "*";
                }

                if (((grade3 >= count * 10) && (grade3 <= count * 10 + 9)) || (count == 9 && grade3 == 100))
                {
                    gradeFrequencyTable += "*";
                }

                if (((grade4 >= count * 10) && (grade4 <= count * 10 + 9)) || (count == 9 && grade4 == 100))
                {
                    gradeFrequencyTable += "*";
                }

                if (((grade5 >= count * 10) && (grade5 <= count * 10 + 9)) || (count == 9 && grade5 == 100))
                {
                    gradeFrequencyTable += "*";
                }
                gradeFrequencyTable += Environment.NewLine;
            }
            return gradeFrequencyTable;
        }
    }
}

﻿using System;

namespace GradeCentre
{
    class Program
    {
        static void Main(string[] args)
        {
            CGradeBook students = new CGradeBook("Application Dev", new int[,] { { 45,56,32,55 }, { 67,56,77,88}, { 66, 22, 44, 55 }, { 89, 86, 69, 76 }, { 100, 56, 33, 77 } });

            Console.WriteLine(students.ModuleName);
            Console.WriteLine(students.GetAllStudentGradesString());
            Console.WriteLine(students.GetAllStudentGradesDistribution());
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Average Mark of student " + i.ToString() + ": " + students.GetStudentAverage(i).ToString());
            }
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine("Minimum Mark: " + students.GetMinimum().ToString());
            Console.WriteLine("Maximum Mark: " + students.GetMaximum().ToString());
        }
    }
}

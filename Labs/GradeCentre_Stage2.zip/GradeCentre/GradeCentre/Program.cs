﻿using System;

namespace GradeCentre
{
    class Program
    {
        static void Main(string[] args)
        {
            CGradeBook students = new CGradeBook("Application Dev", new int[] { 45, 67, 66, 89, 100 });

            Console.WriteLine(students.ModuleName);
            Console.WriteLine(students.GetAllStudentGradesString());
            Console.WriteLine(students.GetAllStudentGradesDistribution());
            Console.WriteLine("Average Mark: " + students.GetAverage().ToString());
            Console.WriteLine("Minimum Mark: " + students.GetMinimum().ToString());
            Console.WriteLine("Maximum Mark: " + students.GetMaximum().ToString());
        }
    }
}

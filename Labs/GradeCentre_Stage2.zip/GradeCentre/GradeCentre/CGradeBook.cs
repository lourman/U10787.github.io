﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeCentre
{
    public class CGradeBook
    {
        // All Student Grades
        private int[] grades;

        /// <summary>
        /// Auto Implemented Property for returning the module name
        /// </summary>
        public string ModuleName { get; }

        /// <summary>
        /// Constructor with name of module and the marks of each of the 5 students
        /// </summary>
        /// <param name="name">Name of the Module</param>
        /// <param name="grade_1">Student 1 Grade</param>
        /// <param name="grade_2">Student 2 Grade</param>
        /// <param name="grade_3">Student 3 Grade</param>
        /// <param name="grade_4">Student 4 Grade</param>
        /// <param name="grade_5">Student 5 Grade</param>
        public CGradeBook(string name, int[] studentGrades)
        {
            ModuleName = name;
            grades = studentGrades;
        }

        /// <summary>
        /// Find the minimum mark of all students
        /// </summary>
        /// <returns>The minimum mark found</returns>
        public int GetMinimum()
        {
            int min = grades[0];

            foreach(int g in grades)
            {
                if (g < min)
                {
                    min = g;
                }
            }
            
            return min;
        }

        /// <summary>
        /// Find the maximum mark of all students
        /// </summary>
        /// <returns>The maximum mark found</returns>
        public int GetMaximum()
        {
            int max = grades[0];

            foreach (int g in grades)
            {
                if (g > max)
                {
                    max = g;
                }
            }

            return max;
        }

        /// <summary>
        /// Calculates the average mark
        /// </summary>
        /// <returns>The average mark</returns>
        public double GetAverage()
        {
            double sum = 0;

            foreach (int g in grades)
            {
                sum += g;
            }

            return sum/grades.Length;
        }

        /// <summary>
        /// Creates a string to shows a list of students with their correspoding mark
        /// </summary>
        /// <returns>A line for each student and their mark for example for a student with mark 23 
        /// it would output:
        /// Student 1: 23
        /// </returns>
        public string GetAllStudentGradesString()
        {
            string allGrades = "";
            for (int i = 0; i < grades.Length; i++)
            {
                allGrades += GradeLine(grades[i], i+1);
                allGrades += Environment.NewLine;
            }           

            return allGrades;
        }

        /// <summary>
        /// Creates a single line for displaying a student mark
        /// </summary>
        /// <param name="grade">the grade associated with the student</param>
        /// <param name="studentid">the id of the student</param>
        /// <returns>Student with a mark for example a student with mark 23 
        /// it would output:
        /// Student 1: 23
        /// </returns>
        private string GradeLine(int grade, int studentid)
        {
            return "Student " + studentid.ToString() + ": " + grade.ToString();
        }

        /// <summary>
        /// Ouptuts a frequency table for each marks between 0-9, 10-19, 20-29,30-39....
        /// </summary>
        /// <returns>The string of the frequency table.</returns>
        public string GetAllStudentGradesDistribution()
        {
            string gradeFrequencyTable = "";
            int[] frequencies = new int[10];

            foreach (int g in grades)
            {
                if (g == 100)
                {
                    ++frequencies[9];
                }
                else
                {
                    ++frequencies[g / 10];
                }
            }

            for (int count = 0; count < 10; count++)
            {
                if (count == 9)
                {
                    gradeFrequencyTable += "90-100: ";
                }
                else
                {
                    gradeFrequencyTable += $"{count * 10:D2} {count * 10 + 9:D2} : ";
                }

                for (int stars = 0; stars < frequencies[count]; stars++)
                {
                    gradeFrequencyTable += "*";
                }               
                
                gradeFrequencyTable += Environment.NewLine;
            }
            return gradeFrequencyTable;
        }
    }
}
